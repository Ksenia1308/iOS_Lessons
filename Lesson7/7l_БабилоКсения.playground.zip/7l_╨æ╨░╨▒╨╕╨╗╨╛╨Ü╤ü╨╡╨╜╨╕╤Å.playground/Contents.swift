import UIKit

enum accountError: Error {
    case noMoney
}

class account {
    var money: Double
    init(value: Double){
        money = value
    }
    func check(summ: Double) throws -> Bool? {
        if money - summ >= 0{
            return true
        }
        throw accountError.noMoney
    }
}

var accmine = account(value:6000.0)
let summ = 5000.0
if let a = try accmine.check(summ: summ) {
    print("Списано: \(summ)")
}

let summ1 = 9000.0
do {
    try accmine.check(summ: summ1)
} catch accountError.noMoney{
    print("Недостаточно денег")
}

